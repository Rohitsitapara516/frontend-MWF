import React,{useState,useEffect} from 'react'
import axios from 'axios';
import { Link } from 'react-router-dom';
export default function Category() {
// destructuring of data via state 
const[data,setData]=useState("");
// fetch data via axios.get() using useEffect hooks
useEffect(()=>{
axios.get(`http://localhost:8000/category`).then((response)=>{
setData(response.data);
})
},[data])
return (
<>
<div className='p-5 bg-blue-600 top-25 sticky  text-white rounded-2xl' style={{height:"80vh"}}>

<ul className='block p-3 m-2  space-y-6'>
{data && data.map((rows)=>{
  return(
    <>
  <li><Link to='' className='text-white text-xl'>{rows.categoryname}</Link></li>
    </>
  )
})}
</ul>

<p className='text-justify w-45'>
  <marquee direction="up">
    <img src="https://freepngimg.com/save/18947-shopping-download-png/564x500" />

  </marquee>
</p>

</div>

</>
)
}

import React,{useState} from 'react'
import { useNavigate,Link} from 'react-router-dom';
import Navbar from './Navbar';
import Footer from './Footer';
import { FaPlus,FaCartPlus } from 'react-icons/fa';
import Swal from 'sweetalert2';
export default function Checkout() {
// destructuring of data via state 
const[data,setData]=useState("");
return (
<>
<Navbar />

<div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
<h1 className="text-3xl font-extrabold text-gray-900 mb-8 border-b pb-4">
Secure Checkout 🔒
</h1>
<div className="md:grid md:grid-cols-3 md:gap-10">
<div className="md:col-span-2 bg-white p-6 rounded-xl shadow-lg mb-8 md:mb-0">
<h2 className="text-2xl font-semibold text-gray-800 mb-6">
1. Shipping Details
</h2>
<form className="space-y-6">
<div>
<label
htmlFor="full_name"
className="block text-sm font-medium text-gray-700"
>
Full Name
</label>
<input
type="text"
id="full_name"
className="mt-1 block w-full border border-gray-300 rounded-lg shadow-sm p-3 focus:ring-indigo-500 focus:border-indigo-500"
placeholder="John Doe"
required=""
/>
</div>
<div className="sm:flex sm:space-x-4 space-y-6 sm:space-y-0">
<div className="sm:w-1/2">
<label
htmlFor="email"
className="block text-sm font-medium text-gray-700"
>
Email Address
</label>
<input
type="email"
id="email"
className="mt-1 block w-full border border-gray-300 rounded-lg shadow-sm p-3 focus:ring-indigo-500 focus:border-indigo-500"
placeholder="you@example.com"
required=""
/>
</div>
<div className="sm:w-1/2">
<label
htmlFor="phone"
className="block text-sm font-medium text-gray-700"
>
Phone Number
</label>
<input
type="tel"
id="phone"
className="mt-1 block w-full border border-gray-300 rounded-lg shadow-sm p-3 focus:ring-indigo-500 focus:border-indigo-500"
placeholder="(555) 123-4567"
/>
</div>
</div>
<div>
<label
htmlFor="address_1"
className="block text-sm font-medium text-gray-700"
>
Address Line 1
</label>
<input
type="text"
id="address_1"
className="mt-1 block w-full border border-gray-300 rounded-lg shadow-sm p-3 focus:ring-indigo-500 focus:border-indigo-500"
placeholder="123 Main St"
required=""
/>
</div>
<div>
<label
htmlFor="address_2"
className="block text-sm font-medium text-gray-700"
>
Address Line 2 (Optional)
</label>
<input
type="text"
id="address_2"
className="mt-1 block w-full border border-gray-300 rounded-lg shadow-sm p-3 focus:ring-indigo-500 focus:border-indigo-500"
placeholder="Apt, Suite, Floor"
/>
</div>
<div className="md:grid md:grid-cols-3 md:gap-4 space-y-6 md:space-y-0">
<div>
<label
htmlFor="city"
className="block text-sm font-medium text-gray-700"
>
City
</label>
<input
type="text"
id="city"
className="mt-1 block w-full border border-gray-300 rounded-lg shadow-sm p-3 focus:ring-indigo-500 focus:border-indigo-500"
required=""
/>
</div>
<div>
<label
htmlFor="state"
className="block text-sm font-medium text-gray-700"
>
State / Province
</label>
<input
type="text"
id="state"
className="mt-1 block w-full border border-gray-300 rounded-lg shadow-sm p-3 focus:ring-indigo-500 focus:border-indigo-500"
required=""
/>
</div>
<div>
<label
htmlFor="zip"
className="block text-sm font-medium text-gray-700"
>
ZIP / Postal Code
</label>
<input
type="text"
id="zip"
className="mt-1 block w-full border border-gray-300 rounded-lg shadow-sm p-3 focus:ring-indigo-500 focus:border-indigo-500"
required=""
/>
</div>
</div>
</form>
<h2 className="text-2xl font-semibold text-gray-800 mt-10 mb-6 border-t pt-6">
2. Payment Details
</h2>
<div className="space-y-6">
<div>
<label
htmlFor="card_number"
className="block text-sm font-medium text-gray-700"
>
Card Number
</label>
<input
type="text"
id="card_number"
className="mt-1 block w-full border border-gray-300 rounded-lg shadow-sm p-3 focus:ring-indigo-500 focus:border-indigo-500"
placeholder="XXXX XXXX XXXX XXXX"
required=""
/>
</div>
<div className="sm:flex sm:space-x-4 space-y-6 sm:space-y-0">
<div className="sm:w-1/2">
<label
htmlFor="expiry"
className="block text-sm font-medium text-gray-700"
>
Expiration Date (MM/YY)
</label>
<input
type="text"
id="expiry"
className="mt-1 block w-full border border-gray-300 rounded-lg shadow-sm p-3 focus:ring-indigo-500 focus:border-indigo-500"
placeholder="01/25"
required=""
/>
</div>
<div className="sm:w-1/2">
<label
htmlFor="cvc"
className="block text-sm font-medium text-gray-700"
>
CVC
</label>
<input
type="text"
id="cvc"
className="mt-1 block w-full border border-gray-300 rounded-lg shadow-sm p-3 focus:ring-indigo-500 focus:border-indigo-500"
placeholder="XXX"
required=""
/>
</div>
</div>
</div>
</div>
<div className="md:col-span-1">
<div className="bg-white p-6 rounded-xl shadow-lg sticky top-8">
<h2 className="text-2xl font-semibold text-gray-800 mb-4 border-b pb-2">
Order Summary
</h2>
<div className="max-h-60 overflow-y-auto space-y-4 pr-2 border-b pb-4">
<div className="flex justify-between items-center">
<span className="text-sm text-gray-600 truncate">
Eco-Friendly Backpack (x1)
</span>
<span className="text-sm font-medium text-gray-800">$65.00</span>
</div>
<div className="flex justify-between items-center">
<span className="text-sm text-gray-600 truncate">
Wireless Headphones (x2)
</span>
<span className="text-sm font-medium text-gray-800">$199.98</span>
</div>
<div className="flex justify-between items-center">
<span className="text-sm text-gray-600 truncate">
Minimalist Desk Lamp (x1)
</span>
<span className="text-sm font-medium text-gray-800">$45.00</span>
</div>
</div>
<div className="space-y-2 mt-4">
<div className="flex justify-between text-gray-600">
<span>Subtotal</span>
<span>$309.98</span>
</div>
<div className="flex justify-between text-gray-600">
<span>Shipping</span>
<span>$15.00</span>
</div>
<div className="flex justify-between text-gray-600 border-b pb-3">
<span>Tax</span>
<span>$15.50</span>
</div>
<div className="flex justify-between text-xl font-bold text-gray-900 pt-3">
<span>Order Total</span>
<span>$340.48</span>
</div>
</div>
<Link to='/order-confirmed'><button
type="button"
className="mt-6 w-full bg-green-600 text-white py-3 rounded-lg text-lg font-semibold hover:bg-green-700 transition duration-150 shadow-md transform hover:scale-[1.01] focus:outline-none focus:ring-4 focus:ring-green-500 focus:ring-opacity-50"
>
Pay $340.48
</button></Link>

<p className="text-xs text-gray-500 mt-3 text-center">
Your order is secured by SSL.
</p>
</div>
</div>
</div>
</div>

<Footer />
</>
)
}

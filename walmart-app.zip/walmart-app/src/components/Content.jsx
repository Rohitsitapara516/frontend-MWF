import React,{useState,useEffect} from 'react'
import Category from './Category'
import axios from 'axios'
import { useNavigate } from 'react-router-dom';
import { FaArrowAltCircleRight } from 'react-icons/fa';
export default function Content() {
// destructuring of data via state 
const[data,setData]=useState("");
const navigate=useNavigate();
// fetch data via axios.get() using useEffect hooks
useEffect(()=>{
axios.get(`http://localhost:8000/products`).then((response)=>{
setData(response.data);
})
},[data])
return (

<>
<div className='w-full p-25 flex'>
<div className='w-1/2 mt-3'>
<Category />
</div>
<div className='w-500 flex flex-wrap'>
{/* fetch products grid */}
{data && data.map((items)=>{
  return(
    <>
   <div className='w-70  p-5'>
    <p className='text-center'><img src={items.photo} alt='photo' className='w-40 h-40 mx-auto' /></p>
    <p className='text-center text-xl'>Rs. {items.newprice} <span><del>{items.oldprice}</del></span></p>
    <p className='text-center'>{items.productname}</p>
    <p className='text-center'><button className='bg-blue-600 text-white rounded-4xl p-2' onClick={(()=>navigate(`/products-details/${items.id}`))}>More Details <FaArrowAltCircleRight className='inline-flex' /></button></p>
   </div>

    </>
  )
})}

</div>
</div>
</>
)
}

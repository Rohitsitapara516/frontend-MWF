import React from 'react'

export default function Footer() {
  return (

        <>
  <div className="flex-grow p-8 text-center text-gray-700">
    <h1 className="text-4xl font-bold mb-4">WallMart App Content</h1>
    <p className="text-lg">Scroll down to see the responsive footer.</p>
  </div>
  {/* START OF FOOTER */}
  <footer className="bg-primary text-secondary pt-12 pb-6 border-t-8 border-blue-600 shadow-xl">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Logo & Newsletter Section */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-8 border-b border-gray-700 pb-10 mb-8">
        {/* Brand Information (Full width on mobile, 1/5 on desktop) */}
        <div className="md:col-span-2 space-y-4">
          <h2 className="text-3xl font-extrabold text-blue-600 tracking-wider">
            Wallmart<span className="text-secondary">Shop</span>
          </h2>
          <p className="text-gray-400 max-w-sm text-sm">
            Quality goods, delivered fast. Join our community for exclusive
            deals and early access to new collections.
          </p>
          {/* Social Icons */}
          <div className="flex space-x-4 pt-2">
            {/* Facebook */}
            <a
              href="#"
              aria-label="Facebook"
              className="text-gray-400 hover:text-rose-400 transition"
            >
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M22.675 0H1.325C.593 0 0 .593 0 1.325v21.351C0 23.407.593 24 1.325 24h11.493v-9.294H9.68v-3.621h3.138V8.473c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.793.143v3.24l-1.921.001c-1.503 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.621h-3.12V24h6.115c.732 0 1.325-.593 1.325-1.325V1.325C24 .593 23.407 0 22.675 0z" />
              </svg>
            </a>
            {/* Instagram */}
            <a
              href="#"
              aria-label="Instagram"
              className="text-gray-400 hover:text-rose-400 transition"
            >
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07c3.277.15 4.924 1.793 5.074 5.074.058 1.266.07 1.646.07 4.85s-.012 3.584-.07 4.85c-.15 3.277-1.793 4.924-5.074 5.074-1.266.058-1.646.07-4.85.07s-3.584-.012-4.85-.07c-3.277-.15-4.924-1.793-5.074-5.074-.058-1.266-.07-1.646-.07-4.85s.012-3.584.07-4.85c.15-3.277 1.793-4.924 5.074-5.074 1.266-.058 1.646-.07 4.85-.07zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.204-6.793 2.64-7.006 7.006-.058 1.28-.072 1.688-.072 4.947s.014 3.667.072 4.947c.204 4.358 2.64 6.793 7.006 7.006 1.28.058 1.688.072 4.947.072s3.667-.014 4.947-.072c4.358-.204 6.793-2.64 7.006-7.006.058-1.28.072-1.688.072-4.947s-.014-3.667-.072-4.947c-.204-4.358-2.64-6.793-7.006-7.006-1.28-.058-1.688-.072-4.947-.072zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zm0 10.158a3.996 3.996 0 110-7.992 3.996 3.996 0 010 7.992zm6.155-10.132a1.44 1.44 0 100-2.88 1.44 1.44 0 000 2.88z" />
              </svg>
            </a>
            {/* Twitter/X */}
            <a
              href="#"
              aria-label="Twitter/X"
              className="text-gray-400 hover:text-rose-400 transition"
            >
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.797-1.574 2.166-2.724-.951.564-2.005.974-3.127 1.195-.899-.957-2.179-1.555-3.593-1.555-3.565 0-6.471 2.906-6.471 6.471 0 .509.057 1.001.168 1.474-5.385-.271-10.15-2.846-13.34-6.753-.554.957-.872 2.074-.872 3.255 0 2.247 1.146 4.223 2.887 5.378-.847-.024-1.644-.261-2.342-.647v.081c0 3.15 2.23 5.78 5.176 6.388-.544.148-1.115.226-1.701.226-.419 0-.82-.041-1.213-.117.821 2.56 3.2 4.43 6.012 4.475-2.203 1.72-4.974 2.744-7.98 2.744-.52 0-1.03-.031-1.534-.09C2.71 20.37 5.753 21.6 9.07 21.6 15.688 21.6 19.467 16.48 19.467 11.054c0-.168-.003-.335-.008-.501.996-.719 1.868-1.614 2.558-2.625z" />
              </svg>
            </a>
          </div>
        </div>
        {/* Newsletter Signup (Full width on mobile, 3/5 on desktop, split among 3 columns) */}
        <div className="md:col-span-3">
          <h3 className="text-xl font-semibold mb-3">
            Subscribe to our Newsletter
          </h3>
          <form className="flex flex-col sm:flex-row gap-2">
            <input
              type="email"
              placeholder="Enter your email address"
              aria-label="Email address for newsletter"
              className="flex-1 px-4 py-2 text-gray-900 bg-white border border-gray-300 rounded-lg focus:ring-rose-500 focus:border-rose-500 shadow-inner"
            />
            <button
              type="submit"
              className="bg-rose-500 hover:bg-rose-600 text-white font-bold py-2 px-6 rounded-lg shadow-md transition transform hover:scale-[1.01] active:scale-[0.98] whitespace-nowrap"
            >
              Subscribe
            </button>
          </form>
        </div>
      </div>
      {/* Main Link Groups */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
        {/* 1. Shop */}
        <div>
          <h3 className="text-lg font-semibold mb-4 text-secondary">Shop</h3>
          <ul className="space-y-3 text-sm">
            <li>
              <a href="#" className="footer-link text-gray-400">
                New Arrivals
              </a>
            </li>
            <li>
              <a href="#" className="footer-link text-gray-400">
                Best Sellers
              </a>
            </li>
            <li>
              <a href="#" className="footer-link text-gray-400">
                Apparel
              </a>
            </li>
            <li>
              <a href="#" className="footer-link text-gray-400">
                Accessories
              </a>
            </li>
            <li>
              <a href="#" className="footer-link text-gray-400">
                Clearance
              </a>
            </li>
          </ul>
        </div>
        {/* 2. Help & Support */}
        <div>
          <h3 className="text-lg font-semibold mb-4 text-secondary">Support</h3>
          <ul className="space-y-3 text-sm">
            <li>
              <a href="#" className="footer-link text-gray-400">
                Contact Us
              </a>
            </li>
            <li>
              <a href="#" className="footer-link text-gray-400">
                FAQs
              </a>
            </li>
            <li>
              <a href="#" className="footer-link text-gray-400">
                Shipping Policy
              </a>
            </li>
            <li>
              <a href="#" className="footer-link text-gray-400">
                Returns &amp; Exchanges
              </a>
            </li>
            <li>
              <a href="#" className="footer-link text-gray-400">
                Order Tracking
              </a>
            </li>
          </ul>
        </div>
        {/* 3. Company */}
        <div>
          <h3 className="text-lg font-semibold mb-4 text-secondary">Company</h3>
          <ul className="space-y-3 text-sm">
            <li>
              <a href="#" className="footer-link text-gray-400">
                Our Story
              </a>
            </li>
            <li>
              <a href="#" className="footer-link text-gray-400">
                Careers
              </a>
            </li>
            <li>
              <a href="#" className="footer-link text-gray-400">
                Affiliates
              </a>
            </li>
            <li>
              <a href="#" className="footer-link text-gray-400">
                Press
              </a>
            </li>
          </ul>
        </div>
        {/* 4. Legal */}
        <div>
          <h3 className="text-lg font-semibold mb-4 text-secondary">Legal</h3>
          <ul className="space-y-3 text-sm">
            <li>
              <a href="#" className="footer-link text-gray-400">
                Terms of Service
              </a>
            </li>
            <li>
              <a href="#" className="footer-link text-gray-400">
                Privacy Policy
              </a>
            </li>
            <li>
              <a href="#" className="footer-link text-gray-400">
                Cookie Policy
              </a>
            </li>
          </ul>
        </div>
        {/* 5. Contact Info (New Section for larger screens) */}
        <div className="col-span-2 md:col-span-1">
          <h3 className="text-lg font-semibold mb-4 text-secondary">
            Get In Touch
          </h3>
          <ul className="space-y-3 text-sm text-gray-400">
            <li className="flex items-center space-x-2">
              {/* Location Icon Placeholder */}
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                />
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                />
              </svg>
              <span>123 Market St, Suite 400, Global City</span>
            </li>
            <li className="flex items-center space-x-2">
              {/* Email Icon Placeholder */}
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8m-2 4v7a2 2 0 01-2 2H5a2 2 0 01-2-2v-7"
                />
              </svg>
              <a href="mailto:support@ecomshop.com" className="footer-link">
                support@ecomshop.com
              </a>
            </li>
            <li className="flex items-center space-x-2">
              {/* Phone Icon Placeholder */}
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                />
              </svg>
              <a href="tel:+18001234567" className="footer-link">
                1-800-123-4567
              </a>
            </li>
          </ul>
        </div>
      </div>
      {/* Bottom Bar - Copyright & Payment */}
      <div className="mt-10 pt-6 border-t border-gray-700 flex flex-col md:flex-row justify-between items-center text-sm text-gray-400 space-y-4 md:space-y-0">
        <p>© 2024 EcomShop, Inc. All rights reserved.</p>
        {/* Payment Icons */}
        <div className="flex space-x-3 items-center">
          <span className="mr-2 text-gray-500">Secured Payments:</span>
          {/* Visa Icon Placeholder */}
          <svg
            className="h-6 w-8 text-secondary"
            viewBox="0 0 38 25"
            fill="currentColor"
          >
            <path
              d="M1.002 0h35.996C37.55 0 38 .447 38 1.002v22.001A1.001 1.001 0 0136.998 24H1.002A1.001 1.001 0 010 22.999V1.002C0 .447.45 0 1.002 0z"
              fill="#1434CB"
            />
            <path
              fill="#FFF"
              d="M8.2 16.965l-2.8-1.572 1.39-7.39h5.138l-1.385 7.39 2.77 1.572zM12.7 8.35v.006h-.114v-.006H8.56l-.116.006V8.35h4.256zM29.5 8.35l-2.4 7.6h4.8l2.4-7.6h-4.8zM26.2 16.965l-2.77-1.572 1.385-7.39h5.138l-1.39 7.39z"
            />
          </svg>
          {/* Mastercard Icon Placeholder */}
          <svg
            className="h-6 w-8 text-secondary"
            viewBox="0 0 38 25"
            fill="currentColor"
          >
            <path
              d="M36.998 0H1.002C.45 0 0 .447 0 1.002v22.001A1.001 1.001 0 001.002 24h35.996A1.001 1.001 0 0038 22.999V1.002C38 .447 37.55 0 36.998 0z"
              fill="#EB001B"
            />
            <path
              d="M19.1 8.3c-2.4 0-4.3 1.9-4.3 4.3s1.9 4.3 4.3 4.3 4.3-1.9 4.3-4.3-1.9-4.3-4.3-4.3zm9.1 0c-2.4 0-4.3 1.9-4.3 4.3s1.9 4.3 4.3 4.3 4.3-1.9 4.3-4.3-1.9-4.3-4.3-4.3z"
              fill="#FF5F00"
            />
            <path
              d="M14.8 12.6c0-2.4-1.9-4.3-4.3-4.3s-4.3 1.9-4.3 4.3 1.9 4.3 4.3 4.3 4.3-1.9 4.3-4.3z"
              fill="#F79510"
            />
          </svg>
          {/* Amex Icon Placeholder */}
          <svg
            className="h-6 w-8 text-secondary"
            viewBox="0 0 38 25"
            fill="currentColor"
          >
            <path
              d="M37.998 0H.002C-.55 0-.998.447-.998 1.002v22.001A1.001 1.001 0 00.002 24h37.996A1.001 1.001 0 0039 22.999V1.002C39 .447 38.55 0 37.998 0z"
              fill="#006FCF"
            />
            <path
              fill="#FFF"
              d="M7.7 7.2v10.5h2.1V7.2H7.7zM12.9 7.2v10.5h2.1V7.2h-2.1zM18.1 7.2v10.5h2.1V7.2h-2.1zM23.3 7.2v10.5h2.1V7.2h-2.1zM28.5 7.2v10.5h2.1V7.2h-2.1z"
            />
          </svg>
        </div>
      </div>
    </div>
  </footer>
  {/* END OF FOOTER --
   */}


    </>
  )
}

import React,{useState,useEffect,useRef} from 'react'
import axios from 'axios'
import { useNavigate,useParams } from 'react-router-dom';
import Navbar from './Navbar';
import Footer from './Footer';
import { FaPlus,FaCartPlus } from 'react-icons/fa';
import Swal from 'sweetalert2';
export default function OrderConfirmed() {
// destructuring of data via state 
const[data,setData]=useState("");
const navigate=useNavigate();
// fetch data via axios.get() using useEffect hooks
useEffect(()=>{
axios.get(`http://localhost:8000/cart`).then((response)=>{
setData(response.data);
})
},[data])

return (
<>
<Navbar />

<div className="max-w-4xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
  <h1 className="text-3xl font-bold text-gray-900 mb-8">Order Confirmed!</h1>
  <nav aria-label="Progress" className="mb-10">
    <ol
      role="list"
      className="flex items-center justify-between text-sm font-medium text-center sm:text-base"
    >
      <li className="flex-1 after:content-[''] after:w-full after:h-0.5 after:bg-green-600 after:inline-block after:transition-all after:duration-500 after:ease-in-out">
        <a
          href="#"
          className="group flex flex-col items-center transition duration-300 ease-in-out"
        >
          <span className="size-8 flex items-center justify-center rounded-full bg-green-600 text-white transition duration-300 ease-in-out">
            <svg
              className="size-5"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M5 13l4 4L19 7"
              />
            </svg>
          </span>
          <span className="mt-2 text-xs sm:text-sm text-green-600 transition duration-300 ease-in-out">
            Shipping
          </span>
        </a>
      </li>
      <li className="flex-1 after:content-[''] after:w-full after:h-0.5 after:bg-green-600 after:inline-block after:transition-all after:duration-500 after:ease-in-out">
        <a
          href="#"
          className="group flex flex-col items-center transition duration-300 ease-in-out"
        >
          <span className="size-8 flex items-center justify-center rounded-full bg-green-600 text-white transition duration-300 ease-in-out">
            <svg
              className="size-5"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M5 13l4 4L19 7"
              />
            </svg>
          </span>
          <span className="mt-2 text-xs sm:text-sm text-green-600 transition duration-300 ease-in-out">
            Payment
          </span>
        </a>
      </li>
      <li className="flex-1 after:content-[''] after:w-full after:h-0.5 after:bg-green-600 after:inline-block after:transition-all after:duration-500 after:ease-in-out">
        <a
          href="#"
          className="group flex flex-col items-center transition duration-300 ease-in-out"
        >
          <span className="size-8 flex items-center justify-center rounded-full bg-green-600 text-white transition duration-300 ease-in-out">
            <svg
              className="size-5"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M5 13l4 4L19 7"
              />
            </svg>
          </span>
          <span className="mt-2 text-xs sm:text-sm text-green-600 transition duration-300 ease-in-out">
            Review
          </span>
        </a>
      </li>
      <li className="flex-1 flex justify-center">
        <div className="flex flex-col items-center transition duration-300 ease-in-out">
          <span className="size-10 flex items-center justify-center rounded-full bg-green-500 text-white ring-4 ring-green-200 animate-pulse transition duration-300 ease-in-out">
            <svg
              className="size-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
              />
            </svg>
          </span>
          <span className="mt-2 text-sm sm:text-base text-green-600 font-bold transition duration-300 ease-in-out">
            Confirmation
          </span>
        </div>
      </li>
    </ol>
  </nav>
  <div className="bg-white shadow-xl overflow-hidden rounded-lg p-6 sm:p-8 transform transition duration-500 ease-in-out scale-100 opacity-100">
    <div className="text-center">
      <div className="mx-auto size-24 flex items-center justify-center rounded-full bg-green-100 mb-4 transform scale-100 transition duration-500 ease-out">
        <svg
          className="size-16 text-green-600"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="1.5"
            d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
          />
        </svg>
      </div>
      <h2 className="text-2xl sm:text-3xl font-extrabold text-green-700 mb-2">
        Order Successfully Placed!
      </h2>
      <p className="text-gray-600 mb-6">
        Your order{" "}
        <span className="font-semibold text-gray-900">#ABC-123456</span> has
        been confirmed. A confirmation email has been sent.
      </p>
    </div>
    <div className="border-t border-gray-200 pt-6">
      <dl className="space-y-4">
        <div className="flex items-center justify-between">
          <dt className="text-sm font-medium text-gray-500">
            Estimated Delivery
          </dt>
          <dd className="text-sm font-medium text-gray-900">Oct 10, 2025</dd>
        </div>
        <div className="flex items-center justify-between">
          <dt className="text-sm font-medium text-gray-500">Total Amount</dt>
          <dd className="text-lg font-bold text-green-600">$199.99</dd>
        </div>
      </dl>
    </div>
    <div className="mt-8 flex flex-col sm:flex-row justify-center space-y-3 sm:space-y-0 sm:space-x-4">
      <a
        href="#"
        className="w-full sm:w-auto px-6 py-3 border border-transparent rounded-lg shadow-sm text-base font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150 ease-in-out"
      >
        Track Your Order
      </a>
      <a
        href="#"
        className="w-full sm:w-auto px-6 py-3 border border-gray-300 rounded-lg shadow-sm text-base font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150 ease-in-out"
      >
        Continue Shopping
      </a>
    </div>
  </div>
</div>


<Footer />
</>
)
}

import React,{useState,useEffect,useRef} from 'react'
import axios from 'axios'
import { useNavigate,useParams } from 'react-router-dom';
import Navbar from './Navbar';
import Footer from './Footer';
import { FaPlus,FaCartPlus } from 'react-icons/fa';
import Swal from 'sweetalert2';
export default function ProductDetails() {
// destructuring of data via state 
const[data,setData]=useState("");
const  categoryname=useRef("");
const  imgurl=useRef("");
const  photo=useRef("");
const  productname=useRef("");
const  oldprice=useRef("");
const  newprice=useRef("");
const  addedate=useRef("");
const  qty=useRef("");
const  descriptions=useRef("");
const{id}=useParams();
const navigate=useNavigate();
// fetch data via axios.get() using useEffect hooks
useEffect(()=>{
axios.get(`http://localhost:8000/products/${id}`).then((response)=>{
setData(response.data);
categoryname.current.value=response.data.categoryname;
imgurl.current.src=response.data.photo;
photo.current.value=response.data.photo;
productname.current.value=response.data.productname;
oldprice.current.value=response.data.oldprice;
newprice.current.value=response.data.newprice;
addedate.current.value=response.data.addedate;
qty.current.value=response.data.qty;
descriptions.current.value=response.data.descriptions;
})
},[data]);

// stored all data in object for post via axios.post()
const addCartData=async(e)=>{
e.preventDefault();
// stored current data in api via object
var insert={
categoryname:categoryname.current.value,
imgurl:imgurl.current.value,
photo:photo.current.value,
productname:productname.current.value,
oldprice:oldprice.current.value,
newprice:newprice.current.value,
addedate:addedate.current.value,
qty:qty.current.value,
descriptions:descriptions.current.value,
}
// call api vai axios.post
try 
{

// pass insert messages 
Swal.fire({
title: "Do you want to add Product in Cart ?",
showDenyButton: true,
confirmButtonText: "Yes",
denyButtonText: `No`
}).then((result) => {
/* Read more about isConfirmed, isDenied below */
if (result.isConfirmed) {
axios.post(`http://localhost:8000/cart`,insert).then(()=>{
Swal.fire("Cart added successfully", "", "success");
e.target.reset();
navigate('/view-cart');
});
} else if (result.isDenied) {
Swal.fire("Error generated", "", "info");
}

})
}
catch(error)
{
console.log('error generating',error)
}

}

return (

<>
<Navbar />
<form onSubmit={addCartData}>
<div className='w-full p-25 flex'>
<div className='w-300 mt-10 p-5 shadow'>
<p className='text-center'><img src={photo} ref={imgurl} alt='photo' className='w-100 h-100 mx-auto' />
<input type='hidden' ref={photo} />
</p>
</div>
<div className='w-500 flex flex-wrap'>
<div className='p-5 mt-12 ms-10'>
<p className=''><span className="text-xl">CategoryName :</span><input type='text' ref={categoryname} style={{border:"none",fontSize:"20px"}} readOnly /></p>

<p className='text-xl font-light mt-3'><span className="text-xl">ProductName :</span><input type='text' ref={productname} style={{border:"none"}} readOnly /></p>

<input type='hidden' ref={oldprice} style={{border:"none"}} readOnly className='w-10 ms-2' />

<p className='text-xl mt-3'>Rs.<input type='text' ref={newprice} style={{border:"none"}} readOnly className='w-10 ms-2' /> -/ </p>

<p className='mt-3'>
<label className='text-xl'>Select qty :</label>
<input type='number' value="1" ref={qty}  readOnly className='w-auto border-1 border-gray-400 p-1' />
</p>

<p className='mt-5'>
<input type='hidden'  ref={addedate} style={{border:"none"}} readOnly className='w-auto h-auto border-1 border-gray-400 p-3' />
</p>

<p className='mt-5'>
<label className='text-xl'>Products Descriptions :</label>
<input type='text'  ref={descriptions} style={{border:"none"}} readOnly className='w-200 h-auto border-1 border-gray-400 p-3 overflow-auto' />
</p>

<p className='ms-0 mt-5 inline-flex'><button type='submit' className='bg-green-600 text-white rounded-4xl p-3'>Continue shopping <FaPlus className='inline-flex' /></button>

<button className='bg-blue-600 ms-3 text-white rounded-4xl p-2'>AddToCart <FaCartPlus className='inline-flex' /></button>
</p>
</div>
</div>

</div>
</form>
<Footer />
</>
)
}

import React,{useState,useEffect,useRef} from 'react'
import axios from 'axios'
import { useNavigate,useParams,Link } from 'react-router-dom';
import Navbar from './Navbar';
import Footer from './Footer';
import { FaPlus,FaCartPlus } from 'react-icons/fa';
import Swal from 'sweetalert2';
export default function ViewCart() {
// destructuring of data via state 
const[data,setData]=useState("");
const navigate=useNavigate();
// fetch data via axios.get() using useEffect hooks
useEffect(()=>{
axios.get(`http://localhost:8000/cart`).then((response)=>{
setData(response.data);
})
},[data])

return (
<>
<Navbar />
<div className="min-h-screen bg-gray-100 p-4 sm:p-6 lg:p-8">
<div className="max-w-7xl mx-auto">
<h1 className="text-3xl font-bold text-gray-900 mb-8">
Your Shopping Cart ({data.length} Items)
</h1>
<div className="lg:grid lg:grid-cols-3 lg:gap-8">

<div className="lg:col-span-2 space-y-4">


{data && data.map((items)=>{
  return(
    <>

<div
className="flex items-center bg-white p-4 rounded-lg shadow-md transition duration-300 hover:shadow-lg **animate-slide-in-fade**"
style={{ animationDelay: "0s" }}
>
<img
className="w-24 h-24 object-cover rounded-md mr-4"
src={items.photo}
alt="Product Image"
/>
<div className="flex-grow">
<h2 className="text-lg font-semibold text-gray-800">
{items.productname}
</h2>
<p className="text-sm text-gray-500">Color: Blue | Size: M</p>
<p className="text-xl font-bold text-indigo-600 mt-1">Rs. {items.newprice}</p>
</div>
<div className="flex items-center space-x-4">
<div className="flex items-center border border-gray-300 rounded-md">
<button className="p-2 text-gray-600 hover:bg-gray-100">-</button>
<input
type="number"
defaultValue={1}
min={1}
className="w-12 text-center border-l border-r border-gray-300 p-2 focus:ring-indigo-500 focus:border-indigo-500"
/>
<button className="p-2 text-gray-600 hover:bg-gray-100">+</button>
</div>

<button type='button' onClick={()=>{navigate(`/delete-cart/${items.id}`)}} className="text-red-500 hover:text-red-700 transition duration-150">
<svg
className="w-5 h-5"
fill="none"
stroke="currentColor"
viewBox="0 0 24 24"
xmlns="http://www.w3.org/2000/svg"
>
<path
strokeLinecap="round"
strokeLinejoin="round"
strokeWidth={2}
d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
/>
</svg>
</button>
</div>
</div>
    </>
  ) 
})}



<div className="pt-4 flex justify-end lg:justify-start">
<a
href="#"
className="text-indigo-600 hover:text-indigo-800 font-medium transition duration-150 flex items-center"
>
<svg
className="w-4 h-4 mr-1"
fill="none"
stroke="currentColor"
viewBox="0 0 24 24"
xmlns="http://www.w3.org/2000/svg"
>
<path
strokeLinecap="round"
strokeLinejoin="round"
strokeWidth={2}
d="M10 19l-7-7m0 0l7-7m-7 7h18"
/>
</svg>
Continue Shopping
</a>
</div>
</div>
<div
className="lg:col-span-1 mt-8 lg:mt-0 **animate-slide-in-fade**"
style={{ animationDelay: "0.3s" }}
>
<div className="bg-white p-6 rounded-lg shadow-xl sticky top-8">
<h2 className="text-2xl font-bold text-gray-900 mb-4 border-b pb-2">
Order Summary
</h2>
<div className="space-y-3">
<div className="flex justify-between text-gray-600">
<span>Subtotal (3 items)</span>
<span className="font-medium">$210.00</span>
</div>
<div className="flex justify-between text-gray-600">
<span>Shipping Estimate</span>
<span className="font-medium">$15.00</span>
</div>
<div className="flex justify-between text-gray-600 border-b pb-3">
<span>Tax Estimate</span>
<span className="font-medium">$10.50</span>
</div>
<div className="flex justify-between text-2xl font-bold text-gray-900 pt-3">
<span>Order Total</span>
<span>$235.50</span>
</div>
</div>
<Link to='/checkout'><button className="mt-6 w-full bg-indigo-600 text-white py-3 rounded-lg text-lg font-semibold hover:bg-indigo-700 transition duration-150 transform hover:scale-[1.01] focus:outline-none focus:ring-4 focus:ring-indigo-500 focus:ring-opacity-50">
Proceed to Checkout
</button></Link>
<div className="mt-4 pt-4 border-t border-gray-200">
<label
htmlFor="coupon"
className="block text-sm font-medium text-gray-700 mb-1"
>
Have a coupon code?
</label>
<div className="flex space-x-2">
<input
type="text"
id="coupon"
placeholder="Enter code"
className="flex-grow p-2 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
/>
<button className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition duration-150">
Apply
</button>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<Footer />
</>
)
}

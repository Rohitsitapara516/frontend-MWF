import React from 'react'

export default function UpdateData() {
  return (
    <div>
      
    </div>
  )
}
